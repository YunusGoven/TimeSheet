﻿# READ ME

Q : Comment accéder à l’onglet help ?
R : Cliquer sur le bouton « ? » en haut à droite de la fenêtre.


Q : Comment se connecter ?
R : Entrez votre login et votre mot de passe puis cliquez sur « Se Connecte »r.

Q : Comment encoder une timesheet ?
R : Cliquez sur le bouton « Encoder une timesheet » et ensuite remplissez le formulaire fourni

Q : Comment ajouter plusieurs activités par jour ?
R : Cliquez sur le bouton + correspondant au jour souhaité

Q : Comment valider une activité ?
R : Cliquez sur le bouton « Valider » une timesheet et cliquez sur le bouton vert afin de valider l'activité

Q : Comment consulter l'historique ?
R : Après avoir fait valider vos timesheets, elles sont disponibles sous le bouton « consulter
l'historique » de votre page d'accueil.

Q : Comment ajouter un utilisateur ?
R : Authentifiez-vous en tant qu'administrateur, ensuite rendez-vous sous le bouton « Ajouter un
utilisateur ».

Contact :
Goven Yunus : y.goven@student.helmo.be
Munno Alessandro : a.munno@student.helmo.be
Delisse Hamza : h.delisse@student.helmo.be
