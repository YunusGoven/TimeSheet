﻿# INSTALL

- Cloner ce projet git ou extraire le zip: TimeSheetMobile.zip
- Déploiement :
o Activer les applications inconnues dans les paramètres de votre smartphone
o Ouvrir le fichier timesheetmobile.apk
o Attendre la fin de l’installation de l’application
o Ouvrir l’application
- Fonctionnalités :
o Authentification
o Ajouter un time sheet
o Valider un time sheet
o Visualiser son historique
o Ajouter un utilisateur
- Bugs connus :
o La vitesse pour charger la base de données
o Adaptation de l’écran lors de l’ajout d’un time sheet avec des petits écrans
o L'historique détaillé d'un time sheet qui ne s'affiche pas complétement
o Panel de l'administration à finir
o Validation d'activité ne se fait pas correctement
